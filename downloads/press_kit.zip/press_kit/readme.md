Thank you for downloading the Invasion Defence press kit.
If you have any questions or need more information, pleas e-mail me <Alek Mlynek> alek@alekmlynek.com.

**What's Included:**
+ 5 Screenshots
+ 3 App Icons
+ 1 Trailer (https://dl.dropboxusercontent.com/u/5563220/id_trailer_2016.mp4)

**Game Description:**
Invasion Defence is a challenging action / arcade shooter. Take control of Earths super-weapons and defend us from the advancing invasion.

This version includes chapter 1, with 15 challenging levels (2 boss fights). It also includes 4 power-ups that you can unlock with 3 star ratings.

Please note that unlike traditional mobile games, Invasion Defence is not a super easy game. While its simple to play, 3 star ratings may require some practice!
